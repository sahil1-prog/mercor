# censored-exposure-forecasting

**Category:** Science
**Subcategory:** Pharmacometrics and statistical modeling
**Difficulty:** Hard
**Estimated expert time:** 10 hours

This summary is prepared for reviewers; it is never visible to the agent.

---

## The task

A clinical pharmacology group requires Day 14 exposure projections (AUC, Cmax, and trough over `[t14, t14+H)`) for an incoming cohort in a once-daily oral multiple-ascending-dose trial. The drug stimulates its own elimination clearance, and approximately 70% of participants step up to twice their initial dose starting on Day 8. Pharmacokinetic sampling in the new cohort occurs exclusively on Days 1, 4, and 7 - entirely before that dose escalation. The Day 14 forecast is therefore a true model extrapolation across dose and time rather than an interpolation from observed concentrations.

**Deliverable:** `/app/submission/predict.py`, run as:
`python3 /app/submission/predict.py --input-dir DIR --output OUT.csv [--horizon-h H] [--estimator E]`.
It emits `subject_id,auc_ss,cmax_ss,ctrough_ss` for each subject. During evaluation, only the input directory and `/app/submission` remain accessible; `/app/data`, `/app/baseline`, and `/app/analysis` are not present.

**Agent-visible material:**
- A dense cohort (`/app/data/rich`, 40 subjects): rich Day 1 and Day 14 profiles with daily trough monitoring.
- A sparse cohort matching the evaluation cohort's sampling protocol (`/app/data/sparse`, 60 subjects).
- A naive baseline predictor script.
- An internal team memo arguing for an incorrect model: stationary clearance, dose linearity, and omitting BLQ samples.

## What success looks like

A successful submission is a standalone prediction pipeline rather than a static table of values. It ingests any cohort conforming to the documented schema and outputs one complete, finite, and positive row per subject. On the unseen 150-subject evaluation cohort, median relative errors must satisfy `raw <= 0.25`, corresponding to `reward >= 0.50`. This threshold must hold across the default 24 h window and all graded windows (1.05, 6.05, 24.05, and 47.95 h). Submissions must also fulfill all behavioral requirements outlined in the instructions:
- reproducible, deterministic outputs;
- adherence to the 120 s runtime limit;
- leaving input directories and the submission directory unmodified;
- independent per-field covariate fallback handling;
- exact `--horizon-h` window integration while rejecting invalid arguments;
- a `population` estimator that ignores observed samples and subject IDs while responding to dose and covariates.

The overall task score is binary: 1 when all 25 verification tests pass, 0 otherwise.

Methodological choices remain unconstrained: candidates may employ any structural model, parameter estimation technique, or numerical solver. In practice, satisfying all criteria across every window requires three components:
- a pharmacokinetic model whose clearance evolves with drug exposure, carrying forward through titration and washout;
- likelihood estimation accounting for below-LLOQ samples rather than discarding them;
- empirical-Bayes individualization calibrated from sparse sampling records.

Measured reference anchors indicate where the performance boundaries lie:

| Anchor | raw at 24 h | reward | Outcome |
|---|---|---|---|
| Naive baseline | 1.768 | 0.000 | fails |
| Dose-and-covariate regression, no PK model | 0.514 | 0.000 | fails |
| Population typical values, no individual fit (true parameters) | 0.256 | 0.487 | fails |
| **Pass bar** | **0.250** | **0.500** | |
| Time-only induction, individualised (true parameters) | 0.181 | 0.638 | passes at 24 h, close to the bar at 47.95 h (0.511) |
| Correct structure, individualised (true parameters) | 0.120 | 0.760 | passes |
| Reference solution (fitted from visible data only) | 0.109 | 0.783 | passes all windows |

The following attempts fail closed and score 0:
- outputs that are missing, malformed, omit subjects, contain non-finite numbers, or fail determinism;
- predictors ignoring CLI flags or rounding window ends onto fixed integration grids;
- a `population` mode that accesses sample concentrations or censoring flags;
- models passing at 24 h but failing on any graded window;
- scripts writing outside the designated output path or modifying input directories.

Partial success, such as satisfying formatting checks without meeting accuracy thresholds, scores 0.

### The 1.0 witness

The reference implementation in `solution/` achieves a score of 1.0. Running `solve.sh` fits `fit_population.py` on `/app/data` and populates `/app/submission` with `predict.py`, `pk_engine.py`, and `pop_params.json`; this submission passes all 25 checks in local Docker runs of both container images. It provides an explicit proof of feasibility rather than a prescribed single approach. A continuous reward of 1.0 would require zero relative error across all metrics - unachievable under assay noise and censoring - but because task grading is binary, the passing witness receives 1.0.

## What makes it hard

The underlying data-generating model (`tests/.truth/truth_model.py`) incorporates:

* First-order oral absorption with an absorption delay (typical 0.4 h) entering a central compartment.
* Systemic clearance `CL0 * E(t)`, where enzyme turnover is driven by circulating drug concentration: `dE/dt = kenz * (1 + Emax*C/(EC50+C)) - kenz*E`. Autoinduction kinetics therefore reflect cumulative dosing history: dose escalation further elevates enzyme levels, while skipped doses permit clearance to decay back toward baseline.
* Patient covariates: allometric body weight scaling on CL0 and V, power scaling of age on CL0, and biological sex effects on CL0 and V.
* Inter-individual variability (IIV) across all 7 parameters (30-40% CV on CL0, Emax, and EC50).
* An analytical assay LLOQ of 2.50 ng/mL: 45% of rich-cohort observations and 25% of sparse-cohort observations are censored, predominantly the trough measurements that contain the autoinduction signal.

A successful solution must identify this structural behavior from data despite the contradictory memo. It must subsequently:
- fit a population PK model under a censored-data likelihood;
- estimate empirical-Bayes individual random effects from just 7 sparse samples per subject;
- integrate exposure forward through an intra-study dose change that unobserved test samples never cover.

**Strongest public prior work, and why it is not enough.** Standard industry packages for these problems include nonlinear mixed-effects (NLME) suites:
- NONMEM and Monolix (commercial);
- nlmixr2, saemix, and mrgsolve in R;
- Pumas in Julia;
- Pharmpy in Python.

Open-source Python NLME engines now exist as well: PKPy2 (github.com/Gumgo91/PKPy2, MIT; joint Laplace and importance-sampling NLME with M3/M4 censoring and user-defined ODEs) and OpenPKPD (github.com/breisfeld/OpenPKPD; FO/FOCE/Laplace/SAEM with M3/M4). PKPDmap (github.com/InsightRX/PKPDmap, MIT) and mapbayr (github.com/FelicienLL/mapbayr) are reference implementations of MAP Bayesian individualisation. The closest public benchmark task is terminal-bench-science proposal #121 (discussion #208, approved): a 2-compartment population fit to 24 sparse Phase 1 subjects with BLQ samples, graded on the recovered population parameters. It has no induction, no dose change and no forecast, and its agent may install packages from the internet. This task differs on each of those points: it is offline, it requires a forecast, and the forecast must extrapolate through a concentration-driven, history-dependent clearance change.

Beal's M3 method for censored observations and turnover-based autoinduction models (such as those described for rifampicin and carbamazepine) are standard literature. However, none of these libraries are installed, and network access is disabled in the container environment. The image provides standard numpy, scipy, and pandas only.

Even with an NLME suite present, core engineering challenges remain. Tooling fits only the structural equations specified by the user and cannot automatically infer that clearance is concentration-driven and history-dependent. Recognizing that behavior requires contrasting Day 14 rich-cohort data against Day 1 profiles, discarding the memo's conclusions, and formulating a model that extrapolates through titration. The test cohort never observes that dose change. As demonstrated in calibration experiments, the plausible shortcut of time-only induction fits the training data yet drops to the edge of the pass bar on the long washout window (reward 0.511 at 47.95 h, against 0.658 for the concentration-driven model).

**Data fidelity.** All trial data is synthetic, simulated from the model described above under fixed seeds. Parameter values reflect realistic clinical ranges for an orally administered small molecule:
- baseline CL0 15 L/h, V 300 L, ka 1.1 /h;
- enzyme turnover half-life of 96 h;
- assay LLOQ with proportional-plus-additive residual error (12% and 0.30 ng/mL), delayed doses (15%), and missed doses (6%) typical of Phase 1 trials.

Synthetic data generation ensures ground truth for the evaluation cohort is mathematically exact and strictly private.

**Who does this work.** This task mirrors the responsibilities of a quantitative clinical pharmacologist or pharmacometrician in sponsor drug development. Following a multiple-ascending-dose trial, the analyst constructs the population PK framework supporting the Phase 2 dose-selection package. They project steady-state exposure for proposed dosing schedules in sparsely sampled populations, directly informing efficacy margins and safety boundaries.

### Calibration with the true generating parameters (default 24 h window)

Each configuration below evaluates a MAP predictor initialized with true population values, isolating one specific structural deviation:

| Predictor | raw | reward | passes |
|---|---|---|---|
| correct structure | 0.120 | 0.760 | yes |
| induction that ignores concentration (time-only) | 0.181 | 0.638 | yes at 24 h; 0.511 at 47.95 h |
| no induction | 1.444 | 0.000 | no |
| population typical values only, no individual fit | 0.256 | 0.487 | no |

Time-only induction fails to capture the dose escalation step and subsequent clearance decay during washout. While it passes at 24 h, it nears the failure threshold at 47.95 h, where the concentration-driven formulation maintains 0.658.

## Scoring

For each subject and metric: `r = |pred - true| / true`.
`raw = 0.5*median(r_AUC) + 0.3*median(r_Cmax) + 0.2*median(r_Ctrough)`.
`reward = clip(1 - raw/0.5, 0, 1)`; a submission passes when `reward >= 0.50` (`raw <= 0.25`).
The mathematical formula, weighing coefficients, and passing bar are preserved from the original task design and remain unchanged. The candidate-facing instructions state only the `raw` loss metric; the reward transformation and pass criteria appear solely in `task.toml`, `tests/test_outputs.py`, and this document.

The final evaluation grade is binary: 1 when all 25 checks pass (including accuracy at default and all test windows), 0 otherwise.

### Why these constants

* **Weights 0.5 / 0.3 / 0.2.** AUC serves as the primary metric for systemic exposure in dose selection, receiving half the weight. Cmax governs peak-related toxicity and carries the next largest weight. Ctrough receives lower weight because it represents the noisiest endpoint, sitting near the assay LLOQ where measurements are frequently censored. Even the reference model exhibits its largest relative error on troughs (median 0.250 at 24 h and 0.524 at 47.95 h, compared to 0.08-0.09 for AUC). Placing higher weight on Ctrough would primarily reward noise near the quantification limit.
* **Median, not mean.** Taking medians prevents outlier subjects with atypical parameter draws from distorting the score, measuring accuracy across typical subjects as required for clinical dose selection.
* **Normaliser 0.5.** A 50% median relative error (`raw = 0.5`) maps directly to reward 0. Measured non-PK shortcuts fall at or beyond this boundary: the multivariable regression shortcut scores 0.514 and the naive baseline scores 1.768. Only predictors with a viable PK model achieve positive reward.
* **Pass bar `reward >= 0.50` (`raw <= 0.25`).** This boundary cleanly separates two classes of predictors:
  - Individualized models with autoinduction pass at 24 h: raw 0.120 using true parameters, 0.109 for the reference solution, and 0.181 for time-only induction. At 47.95 h, the reference solution maintains raw 0.166, while time-only induction nears the passing boundary (reward 0.511). An independently written PKPy2 comparator (see Measured results) scores raw 0.122 at 24 h and 0.172 at 47.95 h, so the bar is reachable by a structurally different correct model, not only by the reference.
  - Predictors lacking individualization fail even with exact population parameters (raw 0.256), as do models omitting induction entirely (raw 1.444).
  The threshold ensures models fit appropriate subject-level dynamics without demanding precision beyond what sparse data can support.
* **Graded windows 1.05 / 6.05 / 24.05 / 47.95 h.** The 1.05 h window evaluates uptake just past the absorption delay. The 0.05 h offsets place window boundaries off whole integration intervals. The 47.95 h window extends nearly a full day into washout beyond the next scheduled dose, revealing discrepancies in clearance dynamics. The reference solution scores 0.806 / 0.872 / 0.782 / 0.667 on these windows.

## Measured results (local Docker, both images built from this package)

All runs executed under `--network none --cpus 4 --memory 8g`, using the agent image for solving and the verifier image for evaluation as specified in `task.toml`.

| Run | Pipeline reward | Detail |
|---|---|---|
| oracle (reference), grade 1 | 1 | 23/23 passed, suite 132 s (previous 23-check suite) |
| oracle (reference), grade 2 | 1 | 23/23 passed, suite 134 s; fresh `solve.sh` into a new volume gave a byte-identical submission (previous suite) |
| oracle (reference), grade 3 | 1 | 24/24 passed, suite 175 s (intermediate 24-check suite, host shared with two other runs) |
| oracle (reference), grade 4 | 1 | 25/25 passed, suite 184 s (current suite, host shared with two other runs) |
| nop (empty submission) | 0 | fails closed: no `/app/submission/predict.py` |
| naive baseline (`/app/baseline/predict.py`) | 0 | 12/23 on the previous suite; fails the accuracy bar (raw 1.768 at 24 h) |
| constant output | 0 | 11/23 on the previous suite; one value copied to every subject, fails the accuracy bar |
| dose-and-covariate regression shortcut | 0 | 13/23 on the previous suite; fails the accuracy bar at raw 0.514 (it scored reward 0.499 before this revision) |
| tamper probe: the reference predictor, plus a write into `/app/submission` only when `--horizon-h` is given | 0 | current suite: 22/25, fails `test_preservation_input_directory_and_submission_untouched`, `test_horizon_accuracy_matches_truth` and `test_zz_preservation_nothing_modified_after_all_runs`. The previous 23-check suite scored the same probe 1 (23/23), which is why the check was extended. |

Reference continuous rewards on the held-out cohort, scored in the verifier image:

| Window | raw | reward | median rel. error AUC / Cmax / Ctrough |
|---|---|---|---|
| 24 h (default) | 0.109 | 0.783 | 0.083 / 0.057 / 0.250 |
| 1.05 h | 0.097 | 0.806 | 0.115 / 0.079 / 0.079 |
| 6.05 h | 0.064 | 0.872 | 0.060 / 0.057 / 0.085 |
| 24.05 h | 0.109 | 0.782 | 0.083 / 0.057 / 0.251 |
| 47.95 h | 0.166 | 0.667 | 0.089 / 0.057 / 0.524 |
| 24 h, `--estimator population` (not graded for accuracy) | 0.246 | 0.508 | 0.178 / 0.118 / 0.610 |

Runtime: `solve.sh` takes roughly 22 s, and full-cohort prediction takes 3.6 s against the 120 s budget.

### Independent comparator (bounds calibration)

To check that the bar is reachable without the reference code, a second predictor was written separately and scored with the real verifier. It is structurally different from `solution/`:
- the population fit is a joint Laplace NLME estimate (all parameters, IIV and residual error together) made with PKPy2 (github.com/Gumgo91/PKPy2, MIT), using M3 censoring and a numba ODE right-hand side;
- the fit used the visible rich and sparse cohorts, starting from generic values (KA 1, V 250, CL0 20, EMAX 5, EC50 20, KENZ 0.01). It converged at OFV 5749.56 after 3013 s;
- individual estimates are PKPy2's Laplace modes, and exposures come from scipy LSODA with an AUC state.

PKPy2 was used only to author the comparator. It is not shipped in either image, and the comparator is not part of the package. The fit recovered KA 1.146 /h, V 321 L, CL0 16.1 L/h and an enzyme half-life of 92 h (generating values: 1.1, 300, 15, 96 h).

| Window | raw | reward | median rel. error AUC / Cmax / Ctrough |
|---|---|---|---|
| 24 h (default) | 0.122 | 0.757 | 0.084 / 0.065 / 0.301 |
| 1.05 h | 0.106 | 0.787 | 0.119 / 0.094 / 0.094 |
| 6.05 h | 0.066 | 0.868 | 0.059 / 0.065 / 0.084 |
| 24.05 h | 0.122 | 0.756 | 0.084 / 0.065 / 0.301 |
| 47.95 h | 0.172 | 0.656 | 0.094 / 0.065 / 0.528 |

Full-cohort prediction takes about 35 s, inside the 120 s budget.

On the first full verifier run the comparator passed 24/25 checks (1281 s suite). It failed `test_covariates_unusable_sex_falls_back` because it stripped whitespace from `sex` and so read `" F "` as female. The instruction said only "not `M`/`F`", so it now says explicitly that `f`, `m` and `" F "` are invalid. After the comparator was fixed to compare `sex` literally, all 7 covariate checks passed. The comparator was not re-run through the full 25-check suite after that fix.

## Verification

* The verifier synthesizes the 150-subject held-out cohort within its container via `tests/.truth/heldout.py` using a fixed seed; this cohort is never present in the solver image. Ground-truth values are integrated across a 0.02 h node grid with exact node placement at every dose event and window boundary.
* No input samples occur within the Day 14 evaluation window (`assert_no_day14_samples`).
* Predictors execute under the unprivileged agent account against root-owned, read-only inputs. Output files are read using `O_NOFOLLOW`.

**"Leave the input directory and `/app/submission` unchanged; write only OUT.csv" is enforced, and a violation scores 0.**
* **Structural guard.** Every input directory, held-out and toy, is root-owned and read-only to the predictor, which owns only a pre-created output leaf.
* **Hash checks.** The verifier SHA-256 hashes the inputs and fingerprints the whole `/app/submission` tree (bytecode caches excepted) when the suite starts. It re-checks them:
  - after the default runs (`test_inputs_unmodified`, `test_deterministic`);
  - after every held-out `--horizon-h` / `--estimator` run (`test_horizon_accuracy_matches_truth`);
  - before and after every toy run (`_run_toy`);
  - in a dedicated criterion, `test_preservation_input_directory_and_submission_untouched`. It runs the predictor on fresh read-only inputs in every invocation shape: default, horizons 6.05 and 47.95 h, both estimators, and two invalid calls. After each run it checks the inputs, the output directory and `/app/submission`;
  - once more after the whole suite (`test_zz_preservation_nothing_modified_after_all_runs`).
* **What fails.** An added, removed or changed file, a symlink, or any extra file in an output directory fails its check.
* **Measured.** A predictor that tampered only under `--horizon-h` passed the previous suite and scores 0 on this one (table above).

| Instruction constraint | Criterion that enforces it | On violation |
|---|---|---|
| Leave the input directory unchanged | input SHA-256 + listing re-checked by `test_preservation_input_directory_and_submission_untouched`, `test_inputs_unmodified` and `test_zz_preservation_nothing_modified_after_all_runs`; toy inputs also before and after every toy run | check fails, reward 0 (floor) |
| Leave `/app/submission` unchanged (bytecode caches excepted) | whole-tree fingerprint vs. suite start, after every run in `test_preservation_input_directory_and_submission_untouched`, plus `test_inputs_unmodified` and the final sweep | check fails, reward 0 (floor) |
| Write OUT.csv and no other file into the output directory | output directory listed after every run; only the requested OUT.csv names may exist; rejected calls must write nothing | check fails, reward 0 (floor) |

**Infrastructure failure errors instead of scoring.** `tests/test.sh` writes no reward before grading completes. It only clears any stale or planted reward file from the locked reward directory. A reward is written only when pytest actually completes:
- exit 0 (every check passed) writes 1;
- exit 1 (a check failed, which is the submission's fault) writes 0;
- a missing `/app/submission/predict.py` also writes 0, because that is an agent that did nothing.

Everything else is an infrastructure error. The script removes any reward file and exits non-zero, so the trial is recorded as an error, not a 0. This covers:
- the reward directory or `/tests` cannot be locked;
- the agent user is missing or is root;
- `setpriv` cannot drop privileges;
- agent processes cannot be stopped;
- pytest exits 2, 3, 4 or 5 (interrupted, internal error, usage error, nothing collected);
- the verifier is killed or times out (3000 s allocation; the suite takes 132-184 s). No reward file exists until grading finishes, so a timeout leaves none.

Measured in Docker:

| Case | Exit | reward.txt |
|---|---|---|
| oracle | 0 | 1 (25/25) |
| nop | 1 | 0 |
| tamper probe | 1 | 0 |
| pytest collection failure, with a planted `reward.txt = 1` | 3 | none (planted file removed) |
| `timeout -s KILL` | 137 | none |
| `timeout -s TERM` | 124 | none |

A predictor that crashes or exceeds its per-run limit (180 s) inside a completed suite fails a check and scores 0. That is the submission's fault, not an infrastructure fault.

**Regrade tolerance (0.0).** Measured characteristics:
- The evaluation cohort and ground-truth values derive deterministically from a fixed seed.
- The test suite requires repeated evaluations to produce identical numeric results (`test_deterministic`, `test_optional_modes_are_deterministic`).
- Consecutive verification runs of the reference solution both scored 1.0, with a fresh `solve.sh` run producing byte-identical submission artifacts.

Given deterministic evaluation and binary scoring, observed variance is 0.0, establishing a regrade tolerance of 0.0.

### Requirement-to-check map (`tests/test_outputs.py`, 25 checks)

| Instruction requirement | Checks |
|---|---|
| Runs the documented CLI and writes OUT.csv | `test_submission_predicts` |
| Columns, one row per subject, finite positive values | `test_output_format` |
| Finishes within the runtime budget | `test_runtime_budget` |
| Accuracy on the held-out cohort (reward >= 0.50) | `test_accuracy_pass_bar` |
| Two runs agree | `test_deterministic`, `test_optional_modes_are_deterministic` |
| Writes only OUT.csv; inputs and submission untouched (every run, every mode) | `test_preservation_input_directory_and_submission_untouched` (the criterion), `test_inputs_unmodified`, `test_deterministic`, `test_horizon_accuracy_matches_truth`, `test_zz_preservation_nothing_modified_after_all_runs`, plus the toy-run guards in every covariate/horizon/estimator check |
| Covariate fallbacks (70 kg, 45 years, M), per field, others unchanged | `test_covariates_missing_row_falls_back`, `test_covariates_unusable_weight_falls_back`, `test_covariates_unusable_sex_falls_back`, `test_covariates_unusable_age_falls_back`, `test_covariates_fallback_matches_default_row`, `test_covariates_fallback_leaves_others_unchanged` |
| `--horizon-h`: default = 24, exact window, graded accuracy, invalid values rejected | `test_horizon_default_matches_explicit_24`, `test_horizon_accuracy_matches_truth`, `test_horizon_window_additivity`, `test_horizon_rejects_invalid_values` |
| `--estimator`: default = map, population ignores samples and ids, responds to dose and weight, differs from map, invalid values rejected | `test_estimator_default_matches_explicit_map`, `test_estimator_population_ignores_samples`, `test_estimator_population_ignores_subject_id`, `test_estimator_population_responds_to_dosing_and_covariates`, `test_estimator_population_differs_from_map`, `test_estimator_rejects_invalid_values` |

## Changes in this revision

In the previous release, a 15-line linear regression of dose and covariates scored reward 0.499 against the 0.50 threshold, and the memo provided exact population parameters. This revision strengthens evaluation rigor while preserving the scoring formula and pass criteria:

* **Do-not-modify enforcement:** the input and submission-tree hash checks now run after every held-out run in every mode, in a dedicated preservation criterion (`test_preservation_input_directory_and_submission_untouched`) that exercises every invocation shape, and in a final sweep (25 checks, was 23). The criteria are indexed at the top of `tests/test_outputs.py` with their floor consequence. A flag-gated tamper probe that passed the old suite now scores 0.
* **Infrastructure failures error instead of scoring:** `tests/test.sh` no longer pre-writes reward 0. A reward is written only when pytest completes (exit 0 writes 1, exit 1 writes 0). Lock, privilege-drop or process-sweep failures, pytest exits 2-5, signals and verifier timeouts exit non-zero with no reward file.
* **Bounds calibrated on an independent implementation:** a PKPy2-based comparator passes the accuracy bar at every graded window (rewards 0.656 to 0.868; see Measured results). Its one failure, reading a padded `" F "` as female, showed that the instruction's `sex` rule was ambiguous, so the instruction now states that `f`, `m` and `" F "` are invalid.
* **Truth model:** concentration-driven enzyme-turnover autoinduction (replacing a static Hill model), absorption lag, age scaling on CL0, wider parameter variance, LLOQ raised from 1.00 to 2.50 ng/mL, and intra-study dose titration (2x increase from Day 8 for ~70% of subjects).
* **Sparse design:** sampling on Days 1, 4, and 7 (previously 1, 7, and 11), strictly preceding dose titration.
* **Data:** visible cohorts regenerated; `rich/targets.csv` deleted.
* **Memo:** rewritten with authentic parameter estimates derived from a naive model fit on the updated data.
* **Graded windows:** updated to 1.05, 6.05, 24.05, and 47.95 h (previously 0.25, 6.05, and 24.05 h, as 0.25 h fell entirely within the absorption delay).
* **`--estimator population`:** evaluated for sample-invariance properties rather than prediction accuracy, since expanded variability places population-only forecasts near 0.508.
* **Age fallback:** explicit fallback to 45 years for missing or invalid `age_years`.
* **Reference solution:** updated and verified against the refined autoinduction dynamics.
* **Agent-facing instruction:**
  - no narrative preamble;
  - no compute allocation or package list;
  - no hint about persisting a model;
  - no reward transform or pass bar (only the `raw` metric is stated);
  - formulas in LaTeX math.
* **`[agent].user`:** designated user account `"agent"` rather than numeric uid.

Because visible data, candidate instructions, and test grading logic were updated, prior benchmark evaluations are superseded.

## Studio runs

No Studio runs recorded on this version yet. Evaluation targets:
- oracle and nop (Claude Opus 4.6);
- writer Astra (Codex) evaluation (target < 0.67 with > 400k uncached tokens);
- reviewer Opus 5.5 evaluation (target < 0.75).

## AI assistance

Anthropic Claude assisted with revision authoring: refining truth model dynamics, running calibration benchmarks, updating reference solution scripts, adjusting test assertions, and documentation. The author defined the clinical challenge, task scope, and private evaluation design.

## Environment

* **Agent image:** `python:3.13-slim-bookworm` (pinned digest) with numpy 2.2.3, scipy 1.15.2, and pandas 2.2.3. Executes under non-root user `agent` (uid 1000) with no network access.
* **Verifier image:** identical base configuration plus pytest 8.4.1 and pytest-json-ctrf 0.6.1. Emits CTRF reports to `/logs/verifier/ctrf.json`.
* **Resources:** 4 CPUs, 8192 MB RAM; working directory `/app`.
